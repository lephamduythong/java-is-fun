package com.ltfullstack.discoverserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiscoverserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
