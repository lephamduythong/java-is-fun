package com.ltfullstack.borrowingservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BorrowingserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
