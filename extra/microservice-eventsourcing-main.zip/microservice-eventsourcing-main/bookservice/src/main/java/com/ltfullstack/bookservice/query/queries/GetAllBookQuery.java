package com.ltfullstack.bookservice.query.queries;

public class GetAllBookQuery {
}
