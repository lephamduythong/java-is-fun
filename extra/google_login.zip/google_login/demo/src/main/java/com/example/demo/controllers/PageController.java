package com.example.demo.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/page")
public class PageController {
	
    @GetMapping("/login-ok")
    public ResponseEntity<String> loginOK(@AuthenticationPrincipal OAuth2User principal) {
        return new ResponseEntity<>("LOGIN OK, YOU CAN CLOSE THIS BROWSER TAB", HttpStatus.OK);
    }
    
}
