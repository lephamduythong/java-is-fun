package com.example.demo.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class APIController {
	
	@GetMapping("/example")
	public ResponseEntity<String> getCourseById(@AuthenticationPrincipal OAuth2User principal) {
		return new ResponseEntity<>("HELLO " + principal.getAttribute("name") + " - " + principal.getAttribute("email"), HttpStatus.OK);
	}
	

    
    @GetMapping("/is-authenticated")
    public String isAuthenticated(Authentication authentication) {
        if (authentication != null && authentication.isAuthenticated()
            && !(authentication.getPrincipal() instanceof String && authentication.getPrincipal().equals("anonymousUser"))) {
            return "✅ User is logged in: " + authentication.getName();
        } else {
            return "❌ User is not logged in.";
        }
    }
	
}
