<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

This is a Spring Boot (Java 11) backend project. The main requirements:
- Expose REST APIs to list files in a directory and download selected files.
- Use Maven for build and dependency management.
- Use Java 11.

Please generate code and suggestions that follow these requirements.
