# Build
Backend: 
```
mvn clean package -DskipTests
```

Frontend: 
```
ng build --configuration production
```