package com.t24.vibi.devtool;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/files")
public class FileController {

    @Value("${file.browse.dir:files}")
    private String BROWSE_DIR;

    @GetMapping
    public List<String> listFiles() {
        File dir = new File(BROWSE_DIR);
        List<String> result = new ArrayList<>();
        listFilesRecursive(dir, "", result);
        return result;
    }

    private void listFilesRecursive(File dir, String path, List<String> result) {
        if (dir.exists() && dir.isDirectory()) {
            for (File file : dir.listFiles()) {
                String relativePath = path.isEmpty() ? file.getName() : path + "/" + file.getName();
                if (file.isFile()) {
                    result.add(relativePath);
                } else if (file.isDirectory()) {
                    listFilesRecursive(file, relativePath, result);
                }
            }
        }
    }

    @GetMapping("test")
    public ResponseEntity<String> test() {
        return ResponseEntity.ok().body("OK");
    }

    @GetMapping("download")
    public ResponseEntity<Resource> downloadFile(@RequestParam("filePath") String filePath) throws IOException {
        File file = new File(BROWSE_DIR, filePath);
        if (!file.exists() || !file.isFile()) {
            return ResponseEntity.notFound().build();
        }
        FileSystemResource resource = new FileSystemResource(file);
        String encodedFilename = URLEncoder.encode(file.getName(), StandardCharsets.UTF_8);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + encodedFilename + "\"")
                .body(resource);
    }
}
